# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flake8_linter_markdown']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=3.7.9,<4.0.0']

entry_points = \
{'console_scripts': ['script_name = {package_name}:{function_name}']}

setup_kwargs = {
    'name': 'flake8-linter-markdown',
    'version': '0.1.0',
    'description': 'Lints Python code blocks in Markdown files using flake8',
    'long_description': '# Flake8 Linter Markdown\n\nAn Flake8 Linter to Markdown files\n\n',
    'author': 'Ricardo Gaya',
    'author_email': 'rrgaya@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/rrgaya/flake8-linter-markdown',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
